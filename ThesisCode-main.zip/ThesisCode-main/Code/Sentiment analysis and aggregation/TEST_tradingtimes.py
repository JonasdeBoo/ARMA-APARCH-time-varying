tweets = self.sentiment_classification().copy()

# Define dates where tweets were sent and days when markets where open
trading_dates = self.trading_dates
unique_dates = tweets['date'].unique().tolist()

# Define open and closing time
open_time = datetime.time(9,30,0)
close_time = datetime.time(20,0,0)

# Define polarities
polarities =['neg', 'pos', 'neu']

# Instantiate empty DataFrame
df_weighted_sentiment = pd.DataFrame()
df_weekend = pd.DataFrame()


# Create fisher score for each unique date in the tweets dataframe
for i in range(len(unique_dates) - 1):
    if (unique_dates[i] in trading_dates):
        bool_array = unique_dates[i] == tweets['date']
        daily_tweets = tweets[bool_array]
        print(daily_tweets[['date', 'time']])
        print(unique_dates[i])
        # Empty weekend DataFrame
        df_weekend = pd.DataFrame()

        # Check if the date is in the open or closing market time
        if any((daily_tweets.time < close_time) & (daily_tweets.time > open_time)):
            df_tweets = daily_tweets[(daily_tweets.time < close_time) & (daily_tweets.time > open_time)]

            weighted_sentiment = weighted_sentiment_calculator(df_tweets, self.metrics, 'sentiment direction',
                                                               polarities, 'compounded sentiment', unique_dates[i],
                                                               'open')
            df_weighted_sentiment = df_weighted_sentiment.append(weighted_sentiment)
            print(f'tweets sent during market open time {df_weighted_sentiment}')

        # Check if the next day is a trading day, if True, make df_tweets with today's post market tweets and
        # tommorrow pre-market tweets
        if any(daily_tweets.time > close_time):
            if (unique_dates[i + 1] in trading_dates):
                bool_array_1 = unique_dates[i + 1] == tweets['date']
                tomorrow_tweet = tweets[bool_array_1]
                after_close_tweets = daily_tweets[(daily_tweets.time > close_time)]
                pre_open_tomorrow = tomorrow_tweet[(tomorrow_tweet.time < open_time)]

                df_tweets = pd.concat([after_close_tweets, pre_open_tomorrow])

                weighted_sentiment = weighted_sentiment_calculator(df_tweets, self.metrics, 'sentiment direction',
                                                                   polarities, 'compounded sentiment',
                                                                   unique_dates[i + 1], 'close')
                df_weighted_sentiment = df_weighted_sentiment.append(weighted_sentiment)
                print(f'tweets sent after market opening, tweets of next day too: {df_weighted_sentiment}')

            # If tweets are sent after market closing and tommorrow is not a weekend day, store them in a separate
            # weekend dataframe
            else:
                # empty DataFrame created in previous weekend
                df_close = daily_tweets[(daily_tweets.time > close_time)]
                df_weekend = df_weekend.append(df_close)

    # Now, add weekend days to DataFrame df_weekend, which will be emptied as soon as a date from unique_dates
    # is in trading_days again
    else:
        bool_array = unique_dates[i] == tweets['date']
        daily_tweets = tweets[bool_array]
        print(f'another day of weekend! {unique_dates[i]}')
        df_weekend = df_weekend.append(daily_tweets)

        # Append premarket tweets the day after the weekend to the weekend tweet DataFrame
        if unique_dates[i + 1] in trading_dates:
            bool_array_2 = unique_dates[i + 1] == tweets['date']
            premarket_tweets_after_weekend = tweets[bool_array_2]
            # Append premarket tweets after weekend to df_weekend
            df_weekend = df_weekend.append(premarket_tweets_after_weekend[(premarket_tweets_after_weekend.time
                                                                           < open_time)])
            df_tweets = df_weekend
            # Calculate weighted sentiment over the weekend and assert the score to premarket score of day
            # after the weekend.
            weighted_sentiment = weighted_sentiment_calculator(df_tweets, self.metrics, 'sentiment direction',
                                                               polarities, 'compounded sentiment',
                                                               unique_dates[i + 1], 'close')

            df_weighted_sentiment = df_weighted_sentiment.append(weighted_sentiment)
            print(f'tommorrow ends the weekend: {df_weighted_sentiment}')

# for trading_day in trading_dates:
#    if trading_day not in unique_dates:
#        data_open = {'date': [trading_day],
#                           'close/open': 'close',
#                           'sentiment': 0,
#                           'n_interactions': 0,
#                           'n_tweets': 0
#                            }
#        data_close = {'date': [trading_day],
#                         'close/open': 'open',
#                           'sentiment': 0,
#                           'n_interactions': 0,
#                           'n_tweets': 0
#                            }
#        df_weighted_sentiment = df_weighted_sentiment.append(data_open, ignore_index=True)
#        df_weighted_sentiment = df_weighted_sentiment.append(data_close, ignore_index=True)
